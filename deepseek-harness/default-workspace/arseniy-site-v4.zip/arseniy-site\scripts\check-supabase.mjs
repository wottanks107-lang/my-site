#!/usr/bin/env node
// ============================================================================
//  Проверка базы и доступов. Запуск: npm run check:db
//
//  Что проверяет:
//    1. все таблицы из миграций существуют;
//    2. публичные данные читаются анонимным ключом;
//    3. ПРИВАТНЫЕ данные анонимным ключом недоступны (ни одной строки);
//    4. анонимный ключ не может ничего записать — даже в публичную таблицу;
//    5. bucket site-assets существует и публичен на чтение.
//
//  Ничего не меняет в базе (кроме попытки запрещённой вставки, которую
//  в случае успеха сразу удаляет).
// ============================================================================
import nextEnv from '@next/env'
import { createClient } from '@supabase/supabase-js'
import WebSocket from 'ws'

const { loadEnvConfig } = nextEnv
loadEnvConfig(process.cwd())

const url = process.env.NEXT_PUBLIC_SUPABASE_URL
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!url || !anonKey || !serviceKey) {
  console.error('\n✖ Нужны все три переменные: NEXT_PUBLIC_SUPABASE_URL,')
  console.error('  NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY и SUPABASE_SERVICE_ROLE_KEY.\n')
  process.exit(1)
}

const options = { auth: { persistSession: false, autoRefreshToken: false }, realtime: { transport: WebSocket } }
const anon = createClient(url, anonKey, options)
const admin = createClient(url, serviceKey, options)

const PUBLIC_TABLES = ['profiles', 'site_settings', 'social_links', 'timeline_events', 'skills', 'projects', 'books']
const PRIVATE_TABLES = ['schedule_events', 'homework', 'homework_checklist', 'notes', 'note_tags', 'goals',
  'goal_tasks', 'workouts', 'workout_exercises', 'finance_months', 'media']
const ALL_TABLES = [...PUBLIC_TABLES, ...PRIVATE_TABLES]

let failures = 0
const ok = label => console.log(`   ✓ ${label}`)
const bad = (label, detail) => { failures++; console.log(`   ✗ ${label}${detail ? ` — ${detail}` : ''}`) }
const head = label => console.log(`\n${label}`)

async function main() {
  console.log(`\nПроверка Supabase → ${url}`)

  // --- 1. Схема -------------------------------------------------------------
  head('Схема базы (service_role):')
  for (const table of ALL_TABLES) {
    const { error } = await admin.from(table).select('id').limit(1)
    if (error) bad(table, error.message)
  }
  if (!failures) ok(`все ${ALL_TABLES.length} таблиц на месте`)

  // --- 2. Публичное чтение --------------------------------------------------
  head('Публичное чтение анонимным ключом:')
  for (const table of PUBLIC_TABLES) {
    const { data, error } = await anon.from(table).select('*').limit(50)
    if (error) bad(table, error.message)
    else ok(`${table} — ${data.length} строк`)
  }

  // --- 3. Приватное закрыто -------------------------------------------------
  head('Приватные таблицы анонимным ключом (ожидаем 0 строк):')
  for (const table of PRIVATE_TABLES) {
    const { data, error } = await anon.from(table).select('*').limit(5)
    if (error) {
      // Ошибка доступа — тоже приемлемый результат: данные закрыты.
      ok(`${table} — доступ отклонён (${error.code ?? error.message})`)
    } else if (data.length === 0) {
      ok(`${table} — 0 строк`)
    } else {
      bad(table, `УТЕЧКА: анонимный ключ видит ${data.length} строк`)
    }
  }

  // --- 4. Запись анонимно запрещена ----------------------------------------
  head('Запись анонимным ключом (ожидаем отказ):')
  const publicInsert = await anon.from('social_links').insert({ label: '__rls_check__', url: 'https://example.com' }).select()
  if (publicInsert.error) ok('social_links — вставка отклонена')
  else {
    bad('social_links', 'анонимный ключ смог записать в публичную таблицу')
    for (const row of publicInsert.data ?? []) await admin.from('social_links').delete().eq('id', row.id)
  }

  const privateInsert = await anon.from('notes').insert({ title: '__rls_check__' }).select()
  if (privateInsert.error) ok('notes — вставка отклонена')
  else {
    bad('notes', 'анонимный ключ смог записать в приватную таблицу')
    for (const row of privateInsert.data ?? []) await admin.from('notes').delete().eq('id', row.id)
  }

  // --- 5. Запись секретным ключом разрешена (он обходит RLS) ---------------
  head('Запись секретным ключом (ожидаем успех):')
  const writeTest = await admin.from('notes').insert({ title: '__check_write__', is_public: false }).select()
  if (writeTest.error) bad('notes', `секретный ключ не может писать: ${writeTest.error.message}`)
  else {
    ok('notes — вставка прошла, RLS обойдён')
    for (const row of writeTest.data ?? []) await admin.from('notes').delete().eq('id', row.id)
  }

  // --- 6. Storage -----------------------------------------------------------
  head('Storage:')
  const buckets = await admin.storage.listBuckets()
  if (buckets.error) bad('storage', buckets.error.message)
  else {
    const bucket = (buckets.data ?? []).find(b => b.id === 'site-assets')
    if (!bucket) bad('site-assets', 'bucket не найден — выполни 0003_storage.sql')
    else if (!bucket.public) bad('site-assets', 'bucket не публичный, картинки не откроются по URL')
    else ok('site-assets — есть, публичный на чтение')
  }

  // --- 7. Данные перенесены? -----------------------------------------------
  head('Данные:')
  const { data: profile } = await admin.from('profiles').select('*').eq('id', 1).limit(1)
  if (!profile?.length) console.log('   • профиль ещё не создан — запусти npm run migrate')
  else ok(`профиль: ${profile[0].name ?? '—'}`)

  for (const table of ['projects', 'goals', 'skills', 'social_links']) {
    const { count } = await admin.from(table).select('id', { count: 'exact', head: true })
    console.log(`   • ${table}: ${count ?? 0}`)
  }

  console.log(failures ? `\n✖ Проблем: ${failures}\n` : '\n✔ Всё в порядке.\n')
  process.exit(failures ? 1 : 0)
}

main().catch(error => {
  console.error(`\n✖ Ошибка проверки: ${error.message}\n`)
  process.exit(1)
})
