// Расписание: разовые события и повторяющиеся (ежедневно, по будням, еженедельно).
import { adminClient } from '../supabase/client'
import { createRepo } from './crud'
import { many } from './errors'
import type { ScheduleEvent } from '../types'

const TABLE = 'schedule_events'
const repo = createRepo<ScheduleEvent>(TABLE, {
  order: [{ column: 'start_time' }],
  publicColumn: null, // расписание приватно
})

export const listEvents = repo.list
export const getEvent = repo.get
export const createEvent = repo.create
export const updateEvent = repo.update
export const removeEvent = repo.remove

/** 1 = понедельник … 7 = воскресенье, как в базе. */
export const isoWeekday = (date: Date): number => ((date.getDay() + 6) % 7) + 1

export const toIsoDate = (date: Date): string => {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60_000)
  return local.toISOString().slice(0, 10)
}

/**
 * События на конкретный день: разовые с этой датой плюс повторяющиеся,
 * которые попадают на этот день недели и ещё не закончились.
 */
export async function listEventsForDate(date: Date): Promise<ScheduleEvent[]> {
  const iso = toIsoDate(date)
  const weekday = isoWeekday(date)
  const all = await repo.list()
  return all.filter(e => {
    if (e.repeat === 'none') return e.event_date === iso
    if (e.repeat_until && e.repeat_until < iso) return false
    if (e.repeat === 'daily') return true
    if (e.repeat === 'weekdays') return weekday <= 5
    if (e.repeat === 'weekly') return e.day_of_week === weekday
    return false
  })
}

/** Раскладка на неделю, начиная с понедельника. */
export async function listWeek(weekStart: Date): Promise<{ date: string; weekday: number; events: ScheduleEvent[] }[]> {
  const days = await Promise.all(
    Array.from({ length: 7 }, (_, i) => {
      const d = new Date(weekStart)
      d.setDate(weekStart.getDate() + i)
      return listEventsForDate(d).then(events => ({ date: toIsoDate(d), weekday: i + 1, events }))
    }),
  )
  return days
}

/** Ближайшие события сегодня и завтра — для карточки на dashboard. */
export async function listUpcoming(limit = 5): Promise<ScheduleEvent[]> {
  const now = new Date()
  const time = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`
  const today = await listEventsForDate(now)
  const tomorrow = await listEventsForDate(new Date(now.getTime() + 86_400_000))
  const later = today.filter(e => e.start_time >= time)
  return [...later, ...tomorrow].slice(0, limit)
}

export const listAllEventRows = (): Promise<ScheduleEvent[]> =>
  many<ScheduleEvent>(TABLE, adminClient().from(TABLE).select('*').order('start_time'))
